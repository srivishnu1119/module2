<html>
	<body>
		<head>
			<title>Welcome to java Script</title>
		<head>
	<body>
		<scrpit>
			document.write("Welcome to java-The scripting Language")
		</scrpit>
	</body>
</html>	