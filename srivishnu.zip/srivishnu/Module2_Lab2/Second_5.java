
public class Second_5 {

	private String firstName;
	private String lastName;
	
	
	 enum Gender{M,F}
		
	Second_5(String firstName,String lastName)
	{
		
		this.firstName=firstName;
		this.lastName=lastName;
		System.out.println("Person Details:");
		System.out.println("________________");
		System.out.println("FirstName :"+firstName);
		System.out.println("LastName :"+lastName);
		System.out.println("Age:20");
		System.out.println("Weight:85.55");
		
	}
	 public void phNo(long phNo)
	 {
		System.out.println("Phone Number :"+phNo);
	 }
	public String getFirstName() {
		return firstName;
	}
	public  void setFirstName(String firstName) {
		this.firstName =firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
	}

}


	

