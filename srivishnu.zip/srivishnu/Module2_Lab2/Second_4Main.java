import java.util.Scanner;

public class Second_4Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		int phNo=scanner.nextInt();
		Second_4 second_4=new Second_4("Sri","Vishnu",'M');
		second_4.phNo(phNo);
	}

}
