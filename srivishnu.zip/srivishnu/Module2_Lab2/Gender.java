
public enum Gender {M,F;





char Gender(char G){
	return G;
}
}