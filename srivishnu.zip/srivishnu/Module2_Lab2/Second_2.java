
public class Second_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number=Integer.parseInt(args[0]);
		if(number<0)
		{
			System.out.println(number+" is Negative");
		}
		else
		{
			System.out.println(number+" is positive");
		}
	}

}
