import java.util.Scanner;

public class PersonMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		new PersonClass("sri","vishnu",'m');
		
	}

}
