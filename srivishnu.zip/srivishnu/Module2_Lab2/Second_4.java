
public class Second_4 {
	String firstName;
	String lastName;
	char gender;
	Second_4(String firstName,String lastName,char gender)
	{
		this.firstName=firstName;
		this.lastName=lastName;
		this.gender=gender;
		System.out.println("Person Details:");
		System.out.println("________________");
		System.out.println("FirstName :"+firstName);
		System.out.println("LastName :"+lastName);
		System.out.println("Gender :"+gender);
		System.out.println("Age:20");
		System.out.println("Weight:85.55");
		
	}
	 public void phNo(long phNo)
	 {
		 System.out.println("Phone Number :"+ phNo);
		
	 }
	public String getFirstName() {
		return firstName;
	}
	public  void setFirstName(String firstName) {
		this.firstName =firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}

}
