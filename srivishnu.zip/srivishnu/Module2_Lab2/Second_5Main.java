
import java.util.Scanner;



public class Second_5Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		int phNo=scanner.nextInt();
		Second_5 second_5=new Second_5("Sri","Vishnu");
		Gender gender=Gender.M;
		System.out.println("Gender :"+gender);
		second_5.phNo(phNo);
		
	}

}
