function dispHello(){
var s="Hello World";
return s;
}