var msg;
var sum;
msg="<p><code>The actual script is in external script file called common.js</code></p>";
function addNos(headVar var,bodyVar var)
{

//TODO: display the contents of the variable "msg" 
document.write(msg);

//TODO: display the addition of two numbers
sum=headVar+bodyVar;
return sum;
}
